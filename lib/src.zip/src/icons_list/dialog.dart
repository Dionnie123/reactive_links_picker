import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:reactive_forms/reactive_forms.dart';

Future showMyDialog(BuildContext context, customLink) async {
  final form = FormGroup({
    'value': FormControl<String>(value: 'dionnie_bulingit@yahoo.com'),
    'custom': FormControl<String>(value: ''),
  });

  return showDialog(
    context: context,
    barrierDismissible: true,
    builder: (BuildContext context) {
      return AlertDialog(
        titlePadding: const EdgeInsets.all(0),
        insetPadding: EdgeInsets.zero,
        buttonPadding: const EdgeInsets.all(0),
        contentPadding: const EdgeInsets.all(0.0),
        actionsPadding: EdgeInsets.zero,
        title: Wrap(
          alignment: WrapAlignment.start,
          crossAxisAlignment: WrapCrossAlignment.center,
          runSpacing: 8.0,
          spacing: 8.0,
          children: [
            const Icon(FontAwesomeIcons.linkedin),
            Text(customLink.label),
          ],
        ),
        content: SizedBox(
          width: 400,
          child: ReactiveForm(
            formGroup: form,
            child: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  ReactiveTextField(
                    showErrors: (control) {
                      return false;
                    },
                    formControlName: 'value',
                  ),
                  const SizedBox(height: 12.0),
                  ReactiveTextField(
                    showErrors: (control) {
                      return false;
                    },
                    formControlName: 'custom',
                    decoration:
                        const InputDecoration(label: Text("Custom Label")),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text('Cancel'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          TextButton(
            child: const Text('Create'),
            onPressed: () {
              Navigator.of(context).pop(customLink.copyWith(
                  value: form.value['value'].toString(),
                  custom: form.value['custom'] as String? ?? ""));
            },
          ),
        ],
      );
    },
  );
}
