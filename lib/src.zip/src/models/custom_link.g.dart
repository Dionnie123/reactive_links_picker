// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'custom_link.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CustomLinkImpl _$$CustomLinkImplFromJson(Map<String, dynamic> json) =>
    _$CustomLinkImpl(
      value: json['value'] as String? ?? "",
      label: json['label'] as String? ?? "Link",
      custom: json['custom'] as String? ?? "",
    );

Map<String, dynamic> _$$CustomLinkImplToJson(_$CustomLinkImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
      'label': instance.label,
      'custom': instance.custom,
    };
