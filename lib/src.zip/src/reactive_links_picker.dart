import 'package:flutter/material.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'helpers/list_extenstion.dart';
import 'fields_list/fields_list.dart';
import 'icons_list/icons_list.dart';
import 'link_types.dart';

class _LinksPicker extends StatefulWidget {
  final List<Map<String, dynamic>> value;
  final Function(List<Map<String, dynamic>>) onValueChanged;

  const _LinksPicker({required this.onValueChanged, this.value = const []});

  @override
  State<_LinksPicker> createState() => __LinksPickerState();
}

class __LinksPickerState extends State<_LinksPicker> {
  List<Map<String, dynamic>> links = [];

  final form = FormGroup({
    'customLinks': FormArray<Map<String, dynamic>>([]),
  });

  FormArray<Map<String, dynamic>> get customLinks =>
      form.control('customLinks') as FormArray<Map<String, dynamic>>;

/*   FormControl<Map<String, dynamic>> customLinkItem(int i) =>
      form.control('customLinks.$i') as FormControl<Map<String, dynamic>>; */

  @override
  void initState() {
    /*  for (var i = 0; i < widget.value.length; i++) {
      customLinks.add(FormGroup({
        'value': FormControl<String>(
            value: widget.value[i]['value'],
            validators: [const RequiredValidator()]),
        'custom': FormControl<String>(value: widget.value[i]['custom']),
        'label': FormControl<String>(value: widget.value[i]['label']),
        'id': FormControl<String>(value: widget.value[i]['id']),
      }));
    }
    links = widget.value;

    form.control('customLinks').value = widget.value; */
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ReactiveForm(
      formGroup: form,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            constraints: const BoxConstraints(minHeight: 150),
            child: FieldsList(
              onUpdate: (index, link) {
                final x = links;
                x.removeAt(index);
                x.insert(index, link.toJson());
                widget.onValueChanged(x);
              },
              onReorder: (oldIndex, newIndex) async {
                Future.delayed(const Duration(milliseconds: 100), () {
                  final x = links;
                  setState(() {
                    x.swap(oldIndex, newIndex);
                  });
                  widget.onValueChanged(x);
                });
              },
              onRemovedAt: (index) {
                setState(() {
                  final x = links;
                  x.removeAt(index);

                  customLinks.removeAt(
                    index,
                    updateParent: true,
                  );
                  widget.onValueChanged(x);
                });
              },
            ),
          ),
          Container(
            constraints: const BoxConstraints(minHeight: 150),
            child: IconsList(
              customLinks: linkTypes,
              onLinkCreated: (customLink) {
                setState(() {
                  final y = links;
                  y.add(customLink.toJson());
                  customLinks.add(FormGroup({
                    'value': FormControl<String>(
                        value: customLink.value,
                        validators: [const RequiredValidator()]),
                    'custom': FormControl<String>(value: customLink.custom),
                    'label': FormControl<String>(value: customLink.label),
                    'id': FormControl<String>(value: UniqueKey().toString()),
                  }));
                  widget.onValueChanged(y);
                });
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ReactiveLinksPicker extends ReactiveFormField<List<Map<String, dynamic>>,
    List<Map<String, dynamic>>> {
  ReactiveLinksPicker({
    Key? key,
    String? formControlName,
    FormControl<List<Map<String, dynamic>>>? formControl,
    final Function(List<Map<String, dynamic>> value)? onChanged,
    List<List<Map<String, dynamic>>> colors = const [],
  }) : super(
          key: key,
          formControlName: formControlName,
          formControl: formControl,
          builder: (field) {
            return _LinksPicker(
              value: field.value ?? [],
              onValueChanged: (customLinks) {
                onChanged != null ? onChanged(customLinks) : ();
                field.control.value = customLinks;
                field.control.markAsDirty();
                field.didChange(customLinks);
                field.control.updateValueAndValidity();
              },
            );
          },
        ) {
    if (this.formControlName == null && this.formControl == null) {
      assert(this.formControlName == null && this.formControl == null,
          'ReactiveLinksPicker requires atleast a formControlName or formControl');
    }
  }

  @override
  ReactiveFormFieldState<List<Map<String, dynamic>>, List<Map<String, dynamic>>>
      createState() => ReactiveFormFieldState<List<Map<String, dynamic>>,
          List<Map<String, dynamic>>>();
}
